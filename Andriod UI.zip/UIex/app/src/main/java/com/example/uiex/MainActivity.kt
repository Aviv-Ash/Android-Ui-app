package com.example.uiex

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.annotation.SuppressLint
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.animation.Animation
import android.view.animation.AnimationSet
import android.view.animation.AnimationUtils
import android.widget.*
import androidx.appcompat.widget.SwitchCompat
import androidx.core.animation.addPauseListener
import androidx.core.animation.doOnRepeat
import androidx.core.content.ContextCompat
import com.google.android.material.bottomsheet.BottomSheetDialog

class MainActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.movieapp)

// animation section
        val ticket_btn=findViewById<Button>(R.id.buytick)
        val rotate_x=ObjectAnimator.ofFloat(ticket_btn,"rotationX",0f,360f).setDuration(5000)
        val rotate_y=ObjectAnimator.ofFloat(ticket_btn,"rotationY",0f,360f).setDuration(5000)
        rotate_x.repeatCount=Animation.INFINITE
        val animatorset=AnimatorSet()
        animatorset.playTogether(rotate_x,rotate_y)
        animatorset.start()

//  bottom sheet section
        ticket_btn.setOnClickListener {
            val bottomS= BottomSheetDialog(this@MainActivity)
            val bottomSheetview= layoutInflater.inflate(R.layout.tickets_dialog,null)

            val number_tickets=bottomSheetview.findViewById<NumberPicker>(R.id.number_picker1)
            val theathre=bottomSheetview.findViewById<NumberPicker>(R.id.number_picker)
            val Child_Or_Adult=bottomSheetview.findViewById<NumberPicker>(R.id.number_picker2)
            val total_sum=bottomSheetview.findViewById<TextView>(R.id.total_sum)

            val location=arrayOf("Tel-Aviv","Eilat","Holon","Hifa")
            val ticket_type=arrayOf("Adult","Child")

            Child_Or_Adult?.minValue=0
            Child_Or_Adult?.maxValue=ticket_type.size-1
            Child_Or_Adult?.displayedValues=ticket_type

            theathre?.minValue=0
            theathre?.maxValue=location.size-1
            theathre?.displayedValues=location

            number_tickets?.minValue = 0
            number_tickets?.maxValue = 12
            number_tickets?.setOnValueChangedListener { numberPicker, i, i2 ->
                val purch_btn=bottomSheetview.findViewById<Button>(R.id.purchase_btn)
                val CorAvalue =Child_Or_Adult?.value
                var venue= theathre?.value?.let { it1 -> theathre?.displayedValues?.get(it1) }
                var price=0
                var toast_txt:String="No tickets have been selected "
                if(CorAvalue==0) {
                    price = i2 * 30
                    total_sum.text = "total of $i2 tickets and the price is $price$"
                    toast_txt="You purchased $i2 Adult Tickets for $venue screening total of $price$"
                }
                else{
                    price = i2 * 15
                    total_sum.text = "total of tickets is $i2 and the price is $price"
                    toast_txt="You purchased $i2 Children Tickets for $venue screening in total of $price$"
                }
                purch_btn?.setOnClickListener {
                    Toast.makeText(this,toast_txt,Toast.LENGTH_LONG).show()
                    bottomS.dismiss()

                }
            }


            bottomS.setContentView(bottomSheetview)
            bottomS.show()

        }
        //change photo code
        val photobtn=findViewById<Button>(R.id.photo_btn)
        val changepic=findViewById<LinearLayout>(R.id.backgroundpic)
        var flag=0
        photobtn.setOnClickListener {
            if(flag==0){
                flag=1
                changepic.background = ContextCompat.getDrawable(applicationContext, R.drawable.pulpic)
            }
            else{
                flag=0
                changepic.background = ContextCompat.getDrawable(applicationContext, R.drawable.pulpfiction)
            }

        }



    }
}
